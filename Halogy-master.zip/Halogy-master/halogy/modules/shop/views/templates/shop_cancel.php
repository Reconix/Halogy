{include:header}

<div id="tpl-shop" class="module">
	
	<div class="col col1">

		<h1>Your order has been cancelled</h1>
	
		<p>No payments have been taken and your cart has been emptied.</p>
	
		<p><a href="/shop">Click here</a> to return to the shop.</p>

	</div>
	<div class="col col2">
	
		<ul class="menu">
			{shop:categories}
		</ul>
	</div>

</div>
	
{include:footer}