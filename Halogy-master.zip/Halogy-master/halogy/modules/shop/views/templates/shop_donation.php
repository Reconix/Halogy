{include:header}

<div id="tpl-shop" class="module">
	
	<div class="col col1">

		<h1>Thank you</h1>
	
		<h2>Your donation payment has been successful.</h2>
	
		<p><a href="/shop">Click here</a> to return to the shop.</p>

	</div>
	<div class="col col2">
	
		<h3>Categories</h3>
	
		<ul class="menu">
			{shop:categories}
		</ul>
	</div>

</div>
	
{include:footer}